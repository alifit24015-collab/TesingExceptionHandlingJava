package validation;

public class DeptException extends Exception {
    public DeptException(String msg) {
        super(msg);
    }
}
