package validation;

public class Validator {

    // Age Validation
    public static void validateAge(int age) throws AgeException {
        if (age < 18 || age > 35) {  // Varsity student realistic range
            throw new AgeException(
                "Invalid Age! Student age must be between 18 and 35"
            );
        }
    }

    // Department Validation
    public static void validateDept(String dept) throws DeptException {

        if (!(dept.equalsIgnoreCase("CSE") ||
              dept.equalsIgnoreCase("ICT") ||
              dept.equalsIgnoreCase("TE") ||
              dept.equalsIgnoreCase("ME") ||
              dept.equalsIgnoreCase("ESRM") ||
              dept.equalsIgnoreCase("CPS") ||
              dept.equalsIgnoreCase("FTNS") ||
              dept.equalsIgnoreCase("Pharmacy") ||
              dept.equalsIgnoreCase("BGE") ||
              dept.equalsIgnoreCase("BMB") ||
              dept.equalsIgnoreCase("Chemistry") ||
              dept.equalsIgnoreCase("Mathematics") ||
              dept.equalsIgnoreCase("Physics") ||
              dept.equalsIgnoreCase("Statistics") ||
              dept.equalsIgnoreCase("ACCT") ||
              dept.equalsIgnoreCase("MGT") ||
              dept.equalsIgnoreCase("English") ||
              dept.equalsIgnoreCase("ECO"))) {

            throw new DeptException(
                "Invalid Department! Please enter a valid department name."
            );
        }
    }
}
